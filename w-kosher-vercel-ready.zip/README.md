# World Kosher Portugal

🏆 **A principal autoridade em certificação kosher em Portugal**

## 🌐 Páginas Disponíveis

- **[Página Inicial](index.html)** - Informações gerais sobre a World Kosher
- **[Certificação](certificacao.html)** - Processo completo de certificação kosher

## 📞 Contato

- **WhatsApp**: [+972 54 308 0390](https://wa.me/972543080390)
- **Email**: [portugal@w-kosher.com](mailto:portugal@w-kosher.com)
- **Facebook**: [World Kosher Facebook](https://www.facebook.com/profile.php?id=61575501917315)

## 🌍 Idiomas Suportados

- 🇵🇹 Português (Padrão)
- 🇬🇧 English
- 🇮🇱 עברית (Hebrew)
- 🇪🇸 Español
- 🇷🇺 Русский (Russian)
- 🇮🇹 Italiano

---

© 2024 World Kosher B.M.MASHGICHIM. Todos os direitos reservados.
